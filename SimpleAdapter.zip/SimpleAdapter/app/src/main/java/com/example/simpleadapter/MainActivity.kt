package com.example.simpleadapter

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ListView
import android.widget.SimpleAdapter

class MainActivity : AppCompatActivity() {
 private val fruitNames= arrayOf(
     "Grapes",
     "Banana",
     "Guava",
     "Orange",
     "Grapes",
     "Banana",
     "Guava",
     "Orange",
     "Grapes",
     "Banana",
     "Guava",
     "Orange",
     "Grapes",
     "Banana",
     "Guava",
     "Orange",
     "Grapes",
     "Banana",
     "Guava",
     "Orange",
     "Grapes",
     "Banana",
     "Guava",
     "Orange",
     "Grapes",
     "Banana",
     "Guava",
     "Orange",
     "Grapes",
     "Banana",
     "Guava",
     "Orange")
    private val fruitImages= arrayOf(
        R.drawable.grapes,
        R.drawable.banana,
        R.drawable.guava,
        R.drawable.grapes,
        R.drawable.orange,
        R.drawable.grapes,
        R.drawable.banana,
        R.drawable.guava,
        R.drawable.grapes,
        R.drawable.orange,
        R.drawable.grapes,
        R.drawable.banana,
        R.drawable.guava,
        R.drawable.grapes,
        R.drawable.orange,
        R.drawable.grapes,
        R.drawable.banana,
        R.drawable.guava,
        R.drawable.grapes,
        R.drawable.orange,
        R.drawable.grapes,
        R.drawable.banana,
        R.drawable.guava,
        R.drawable.grapes,
        R.drawable.orange,
        R.drawable.grapes,
        R.drawable.banana,
        R.drawable.guava,
        R.drawable.grapes,
        R.drawable.orange,
        R.drawable.grapes,
        R.drawable.banana,
        R.drawable.guava,
        R.drawable.grapes,
        R.drawable.orange,
        R.drawable.grapes,
        R.drawable.banana,
        R.drawable.guava,
        R.drawable.grapes,
        R.drawable.orange
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val listView=findViewById<ListView>(R.id.listView)
        val list=ArrayList<HashMap<String,Any>>()

        for (i in fruitNames.indices) {
            val map = HashMap<String, Any>()
            map["fruitName"]=fruitNames[i]
            map["fruitImages"]=fruitImages[i]
            list.add(map)
        }
        val from= arrayOf("fruitName","fruitImages")
        val to = intArrayOf(R.id.textView,R.id.imageview)
        val simpleAdapter=SimpleAdapter(this,list,R.layout.list_row_items,from,to)
        listView.adapter = simpleAdapter

    }
}
